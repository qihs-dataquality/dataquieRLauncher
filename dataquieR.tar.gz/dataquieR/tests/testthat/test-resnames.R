# test_that("resnames works", {
#   # tested implictly by test-nres.R
# })
