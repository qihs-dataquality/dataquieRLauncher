# options("testthat.default_reporter" = testthat::RStudioReporter)
library(dataquieR)
testthat::test_check("dataquieR")
