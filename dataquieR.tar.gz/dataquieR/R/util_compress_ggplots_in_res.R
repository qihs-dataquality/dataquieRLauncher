################################################################################
#' Remove specific classes from a ggplot `plot_env` environment
#'
#' Useful to remove large objects before writing to disk with `qs` or `rds`.
#' Also deletes parent environment of the plot environment.
#' Also deletes unneeded variables
#'
#' @param r the object
#'
#' @seealso [HERE](https://github.com/tidyverse/ggplot2/issues/3619#issuecomment-628021555)
#'
util_compress_ggplots_in_res <- function(r) {
  if (isTRUE(attr(r, "from_ReportSummaryTable"))) {
    return(NULL) # never store plots of reportsummarytables, because the original objects are already in the report
  }
  if (ggplot2::is.ggplot(r)) {
    r$plot_env <- emptyenv()
    if (util_ensure_suggested("gginnards", err = FALSE)) {
      # r <- gginnards::drop_vars(r) # see https://github.com/aphalo/gginnards/issues/1
      mv <- gginnards::mapped_vars(r)
      r$data <- r$data[, mv, drop = FALSE]
    }
  } else if (is.list(r)) {
    r[] <- lapply(r, util_compress_ggplots_in_res)
    r[vapply(r, is.null, logical(1))] <- NULL
  }
  return(r)
}
