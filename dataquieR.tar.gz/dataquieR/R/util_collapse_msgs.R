# collect all errors, warnings, or messages so that they are combined for a combined result
util_collapse_msgs <- function(class, all_of_f) { # class is either error, warning or message
  msgs <- lapply(lapply(all_of_f, attr, class), vapply, conditionMessage, FUN.VALUE = character(1)); # extract and create a list of all the messages by class
  # the messages are grouped to avoid repetitions, so the messages are amended
  nms <- gsub("^.*?\\.", "", names(msgs), perl = TRUE)
  # remove variable names
  dfr <- do.call(rbind.data.frame, mapply(SIMPLIFY = FALSE, msgs, nms, FUN = function(msg_lst, varname) {
    msg_lst <- gsub(sprintf("(\\W|^)%s(\\W|$)", varname), "<VARIABLE>", msg_lst, perl = TRUE)
    if (length(msg_lst) > 0) {
      r <- data.frame(varname = varname, message = msg_lst)
    } else {
      r <- data.frame(varname = character(0), message = character(0))
    }
    r
  }))
  # remove numbers
  dfr$message <- gsub("(\\W|^)\\d+(\\W|$)", " <NUMBER> ", dfr$message, perl = TRUE)
  dfr$message <- trimws(gsub(" +", " ", dfr$message, perl = TRUE))
  if (!prod(dim(dfr))) {
    return(character(0))
  }
  # group messages
  dfr <- dplyr::summarize(dplyr::group_by(dfr, message), varname =
                            paste(get("varname"), collapse = ", "))
  msgs <-
    mapply(dfr$varname, dfr$message,
           FUN = function(name, msg) {
             nm <- dQuote(strsplit(name, ", ", fixed = TRUE)[[1]])
             if (length(nm) > 5) { # truncate variable names for the current warning message group
               nm <- c(head(nm, 4), "...")
             }
             paste0("For ", paste(nm, collapse = ", "), ": ", msg)
           })
  unname(msgs)
}
