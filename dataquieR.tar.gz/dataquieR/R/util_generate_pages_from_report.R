#' Convert a [dataquieR report v2][dq_report2] to a named list of web pages
#'
#' @param report [dataquieR report v2][dq_report2].
#' @param template [character] template to use, only the name, not the path
#' @param disable_plotly [logical] do not use `plotly`, even if installed
#' @param progress [`function`] lambda for progress in percent -- 1-100
#' @param progress_msg [`function`] lambda for progress messages
#' @param block_load_factor [numeric] multiply size of parallel compute blocks
#'                                    by this factor.
#'
#' @return named list, each entry becomes a file with the name of the entry.
#'         the contents are `HTML` objects as used by `htmltools`.
#' @examples
#' \dontrun{
#' devtools::load_all()
#' prep_load_workbook_like_file("meta_data_v2")
#' report <- dq_report2("study_data", dimensions = NULL, label_col = "LABEL");
#' save(report, file = "report_v2.RData")
#' report <- dq_report2("study_data", label_col = "LABEL");
#' save(report, file = "report_v2_short.RData")
#' }
util_generate_pages_from_report <- function(report, template,
                                            disable_plotly,
                                            progress = progress,
                                            progress_msg = progress_msg,
                                            block_load_factor) {
  util_ensure_suggested(pkg = c("htmltools"),
                                goal = "generate interactive HTML-reports.")
  have_plot_ly <- util_ensure_suggested(pkg = c("plotly"),
                                        goal = "generate interactive figures in plain HTML-reports.",
                                        err = FALSE)
  if (disable_plotly) have_plot_ly <- FALSE

  if (have_plot_ly) {
    plot_figure <- util_plot_figure_plotly
  } else {
    plot_figure <- util_plot_figure_no_plotly
  }

  vars_in_rep <- rownames(report)

  meta_data <- attr(report, "meta_data")
  label_col <- attr(report, "label_col")


  pages <- list()
  call_env <- environment()

  append_single_page <- function(drop_down_to_attach, # main menu entry (first-level)
                                 div_name, # sub-menu entry (second-level)
                                 file_name, # name where the page is stored, it is possible to add more than one page to a file
                                 ...) { # ... are the contents in htmltools compatible objects
    if (file_name %in% names(call_env$pages)) {
      fil <- call_env$pages[[file_name]]
    } else {
      fil <- list()
    }
    all_ids <- unlist(lapply(call_env$pages, names))
    if (div_name %in% all_ids) {
      util_error("Cannot create report, single page with ID %s already exists",
                 dQuote(div_name))
    }
    sp <- util_attach_attr(htmltools::div(
      ...,
      class = "singlePage",
      id = div_name
    ), dropdown = drop_down_to_attach)
    fil[[div_name]] <- sp
    call_env$pages[[file_name]] <- fil
    invisible(NULL)
  }

  apmat <-
    util_html_table(summary(report, aspect = "applicability", FUN = util_get_html_cell_for_result),
                    filter = "top", options = list(scrollCollapse = TRUE, scrollY = "75vh"),
                    is_matrix_table = TRUE, rotate_headers = TRUE,
                    meta_data = meta_data,
                    label_col = label_col,
                    dl_fn = "Applicability_Matrix",
                    output_format = "HTML"
  )

  ismat <-
    util_html_table(summary(report, aspect = "issue", FUN = util_get_html_cell_for_result),
                    filter = "top", options = list(scrollCollapse = TRUE, scrollY = "75vh"),
                    is_matrix_table = TRUE, rotate_headers = TRUE,
                    meta_data = meta_data,
                    label_col = label_col,
                    dl_fn = "Issue_Matrix",
                    output_format = "HTML"
  )

  # TODO ismat_indicator_based_and_with_metrics
  # TODO apmat_not_segments_and_other_non_item_levels

  ermat <-
    util_html_table(summary(report, aspect = "error", FUN = util_get_html_cell_for_result),
                    filter = "top", options = list(scrollCollapse = TRUE, scrollY = "75vh"),
                    is_matrix_table = TRUE, rotate_headers = TRUE,
                    meta_data = meta_data,
                    label_col = label_col,
                    dl_fn = "Error_Matrix",
                    output_format = "HTML"
  )

  # TODO: add some hints if there is an integrity issue
  append_single_page("General",
                     "Summary",
                     "report.html",
                     htmltools::htmlTemplate( # TODO: EK add, wheter meta data has been guessed
                       text_ = readLines(system.file("templates", template, "overview.html",
                                                     package = utils::packageName())),
                       ismat = ismat,
                       apmat = apmat,
                       ermat = ermat,
                       util_float_index_menu = util_float_index_menu,
                       util_map_labels = util_map_labels,
                       util_get_concept_info = util_get_concept_info,
                       util_abbreviate = util_abbreviate)
  )


  meta_data_frames <-
    grep("^meta_data", names(attributes(report)), value = TRUE)

  meta_data_titles <- c(
    meta_data_segment = "Segment-Level Metadata",
    meta_data_dataframe = "Dataframe-Level Metadata",
    meta_data_cross_item = "Cross-Item-Level Metadata",
    meta_data = "Item-Level Metadata"
  )

  for (mdn in meta_data_frames) {

    xlmd <- attr(report, mdn) # x level metadata

    if (mdn == "meta_data") {
      # these two columns should have been replaced by the v1->v2 conversion of the metadata in
      # prep_meta_data_v1_to_item_level_meta_data (.util_internal_normalize_meta_data)
      xlmd[[MISSING_LIST]] <- NULL
      xlmd[[JUMP_LIST]] <- NULL
    }

    for (cn in grep("_TABLE$", colnames(xlmd), value = TRUE)) {

      xlmd[!util_empty(xlmd[[cn]]), cn] <- vapply(FUN.VALUE = character(1),
        xlmd[!util_empty(xlmd[[cn]]), cn],
        FUN = function(tn) {
          paste(as.character(htmltools::a(href = paste0(tn, ".html"), tn)),
                collapse = "")
        }
      )

    }

    meta_data_table <- util_html_table(
      xlmd, # generate links in VAR_NAMES/Variables, only possible if meta_data and label_col are available
      meta_data = meta_data,
      label_col = label_col,
      dl_fn = mdn,
      output_format = "HTML" # needed for generating plain html, "RMD" would generate a mix between Rmd and html
    )
    tmpl <- system.file("templates", template, paste0(mdn, ".html"),
                        package = utils::packageName())
    if (!file.exists(tmpl)) {
      tmpl <- system.file("templates", template,
                          paste0("generic_meta_data.html"),
                          package = utils::packageName())
    }

    meta_data_title <- meta_data_titles[[mdn]]
    if (length(meta_data_title) != 1 ||
        !is.character(meta_data_title) ||
        util_empty(meta_data_title)) {
      meta_data_title <- mdn
    }

    append_single_page("General",
                       meta_data_title,
                       paste0(mdn, ".html"),
                       htmltools::htmlTemplate(
                         tmpl,
                         meta_data_name = mdn,
                         meta_data_title = meta_data_title,
                         meta_data_table = meta_data_table,
                         )
    )
  }

  referred_tables <- attr(report, "referred_tables")
  if (length(referred_tables)) { # show all tables referred to by the report
    for (reftab in names(referred_tables)) {
      append_single_page("General",
                         reftab,
                         paste0(reftab, ".html"),
                         htmltools::h1(dQuote(reftab)),
                         util_html_table(
                           referred_tables[[reftab]], # generate links in VAR_NAMES/Variables, only possible if meta_data and label_col are available
                           meta_data = meta_data,
                           label_col = label_col,
                           dl_fn = "Item-Level_Metadata",
                           output_format = "HTML" # needed for generating plain html, "RMD" would generate a mix between Rmd and html
                         )
      )
    }
  }

  properties <- attr(report, "properties")
  if (!is.list(properties)) {
    properties <- list(error = "No report properties found, report file corrupted?")
  }

  if (is.list(properties)) {
    # TODO: jsTree
    p <- properties
    p[vapply(p, is.call, FUN.VALUE = logical(1))] <-
      vapply(lapply(p[vapply(p, is.call, FUN.VALUE = logical(1))], deparse),
             paste, collapse = "\n", FUN.VALUE = character(1))
    p <- p[vapply(p, is.vector, FUN.VALUE = logical(1))]
    p <- p[vapply(p, length, FUN.VALUE = integer(1)) == 1]
    p <- data.frame(`  ` = names(p),
                    ` ` = unlist(unname(p)),
                    stringsAsFactors = FALSE,
                    check.names = FALSE)
    append_single_page("General",
                       "Report Information",
                       "report.html",
                       htmltools::tagList(
                         util_html_table(p,
                                         dl_fn = "Report_Information"),
                         htmltools::p(htmltools::tags$i(id = "render-time",
                           sprintf("Rendered using %s %s at %s",
                                   utils::packageName(),
                                   as.character(packageVersion(
                                     utils::packageName())),
                                   as.character(Sys.time()))
                           )),
                         htmltools::tags$script( # https://stackoverflow.com/a/34579496
                         '$(function() {
                              var xx = $("#render-time").html()
                              var data = window.renderingData
                              if (data.hasOwnProperty("renderingTime")) {
                                $("#render-time").html(xx + " in " + data.renderingTime)
                              } else {
                                $("#render-time").html(xx + " -- no rendering time available.")
                              }
                              console.log(data);
                          });'),
                         htmltools::hr(),
                         do.call(htmltools::tagList, lapply(format(
                           utils::readCitationFile(system.file("CITATION",
                                            package = utils::packageName()),
                                            list(Encoding = "UTF-8")),
                           style="HTML"),
                                                            htmltools::HTML)),
                         htmltools::tags$button(class = "clipbtn",
                                           `data-clipboard-text` = paste(
                                             format(
                                               utils::readCitationFile(
                                                 system.file("CITATION",
                                                   package =
                                                     utils::packageName()),
                                                     list(Encoding = "UTF-8")),
                                                style="bibtex"),
                                             collapse = "\n\n"),
                                           "\U1F4CB BibTeX",
                                           title = "copy BibTeX to clipboard")
                        ))
  }

  # generate Venn diagram
  v_in_m <- meta_data[[VAR_NAMES]]
  v_in_s <- attr(report, "study_data_dimnames")[[2]] # dimnames [[1]] is missing
  if (util_ensure_suggested("ggvenn",
                        goal =
                "display Venn diagrams about the meta_data/study_data coverage",
                err = FALSE)) {

    overlap <-
      plot_figure(ggvenn::ggvenn(
        list(`Item-level metadata` = v_in_m, `Study data` = v_in_s),
        set_name_size = 4,
        text_size = 3,
        stroke_size = 0.5))
  } else {
    overlap <-
      util_html_table(data.frame(
        check.names = FALSE,
        ` ` = c("Study Variables with metadata",
                "Study Variables w/o metadata",
                "Variables from DD w/o Study Data"),
        `#` = c(length(intersect(v_in_m, v_in_s)),
                length(setdiff(v_in_s, v_in_m)),
                length(setdiff(v_in_m, v_in_s)))
      ),
      meta_data = meta_data,
      label_col = label_col,
      dl_fn = "StudyMetaDataOverlap",
      output_format = "HTML")
  }

  append_single_page("General",
                     "meta_data/study_data coverage",
                     "report.html",
                     htmltools::h1("meta_data/study_data coverage"),
                     overlap)

  append_single_page("General",
                     "study_data dimensions",
                     "report.html",
                     htmltools::h1("study_data dimensions"),
                     htmltools::p(sprintf(
                       "There are %d observations of %d study variables in the study data",
                       length(attr(report, "study_data_dimnames")[[1]]),
                       length(attr(report, "study_data_dimnames")[[2]])
                       )))


  # rfile <- tempfile()
  # prep_save_report(report, file = rfile)
  # sfile = tempfile()
  # cat(sprintf("report <- prep_load_report(\"%s\")\n", rfile), file = sfile)
  if (!getOption("parallelMap.mode", "local") %in% c("local", "multicore")) {
    util_error(c("On a non-local/multicore cluster,",
                 "parallel rendering of reports is not supported.",
                 "Please call %s before",
                 "rendering the report."),
               dQuote("parallelMap::parallelStop()")
    )
    # IDEA: Addd to DESCRIPTION:
    # biocViews: Software
    # and
    # Suggests: SharedObject
    # BUT: This is not working, the package in unstable and has trouble with
    # the ulimti/stack size
    # if (util_ensure_suggested("SharedObject", "render reports in parallel",
    #                           err = FALSE)) {
    #   r <- report
    #   rm(report)
    #   gc(verbose = FALSE, full = TRUE)
    #   util_message("Sharing report with the workers")
    #   report <- SharedObject::share(r)
    # } else {
    #   util_error(c("On a non-local/multicore cluster,",
    #                "parallel rendering of reports is not supported",
    #                "without having %s installed. Please call %s before",
    #                "rendering the report, or install %s from %s."),
    #              dQuote("SharedObject"),
    #              dQuote("parallelMap::parallelStop()"),
    #              dQuote("SharedObject"),
    #              dQuote(
    # "http://www.bioconductor.org/packages/release/bioc/html/SharedObject.html")
    #              )
    # }
  }

  suppressWarnings(parallelMap::parallelExport("report", "have_plot_ly", "template"))
  parallelMap::parallelLibrary(utils::packageName())
  # parallelMap::parallelSource(sfile, master = FALSE)

# TODO: if https://community.plotly.com/t/cant-show-heatmap-inside-div-error-something-went-wrong-with-axis-scaling/30616/9 is fixed, use auto-sizing

  dim_pages <- util_html_for_dims(
    report,
    use_plot_ly = have_plot_ly,
    template = template,
    block_load_factor = block_load_factor
  )

  dim_pages <- dim_pages[vapply(dim_pages, length, FUN.VALUE = integer(1))
                         != 0]

  progress_msg("Page generation", "Mounting indicator pages")
  i <- 0
  n <- dim(dim_pages)
  for (args in dim_pages) {
    do.call(append_single_page, args) # creates the indicator related pages because cur_var has not yet been set
    progress(i/n * 100)
  }

  util_setup_rstudio_job("Page generation: Single Variable View")

  progress_msg("Page generation", "Generating single variable pages")

  i <- 0
  n <- nrow(report)

  cores <- getOption("parallelMap.cpus", 1)
  if (!is.numeric(cores) || !util_is_integer(cores) || !is.finite(cores)) {
    cores <- 1
  }
  block_size <- block_load_factor * cores
  nblocks <- ceiling(nrow(report) / block_size)
  for (cur_block in seq_len(nblocks) - 1) { # create the single variable pages
    block_indices <- seq(1 + cur_block * block_size,
                         min(cur_block * block_size + block_size,
                                              nrow(report)))
    vars_in_chunk <- rownames(report)[block_indices]
    progress(i/n * 100)
    progress_msg("Page generation", sprintf("Single Variables %s",
                                            paste(sQuote(vars_in_chunk),
                                                  collapse = ", ")))
    chunk_of_pages <- parallelMap::parallelLapply(
      vars_in_chunk,
      function(cur_var) {
        util_html_for_var(
          report,
          cur_var = cur_var,
          use_plot_ly = have_plot_ly,
          template = template)
      }
    )
    chunk_of_pages <- do.call(`c`, chunk_of_pages)
    for (args in chunk_of_pages) {
      do.call(append_single_page, args)
    }
    i <- i + length(vars_in_chunk)
    progress(i/n * 100)
  }

# browser()
  pages
}
