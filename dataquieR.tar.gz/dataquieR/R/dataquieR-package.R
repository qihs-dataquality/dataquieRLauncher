#' @title The `dataquieR` package about Data Quality in
#'        Epidemiological Research
#' @name dataquieR
#' @aliases dataquieR-package
#' @docType package
#' @description
#' For a quick start please read [dq_report2] and maybe the vignettes
#' or the package's [website](https://dataquality.qihs.uni-greifswald.de/).
#'
NULL
#> NULL
