#' Merge a list of study data frames to one (sparse) study data frame
#'
#' @param study_data_list [list] the list
#'
#' @return [data.frame] [study_data]
#' @export
prep_merge_study_data <- function(study_data_list) {
  # TODO: Implement me!
  # Reduce(merge, study_data_list) # similar to this,
  # see sq2psqlrepository:::getStudyData.sq2psqlRepository
}
