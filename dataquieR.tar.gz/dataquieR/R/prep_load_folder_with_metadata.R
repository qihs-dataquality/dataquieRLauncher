prep_load_folder_with_metadata <- function() {
# TODO
}
